package labproject;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;

public final class Frame4 extends JFrame {

    private ImageIcon icon;
    private JTextArea ta;
    private JLabel label1, label2, label3, label4, label5, description;
    private JButton B1;
    private JTable table;
    private JLabel imgLabel;
    private ImageIcon i;
    private JComboBox cb, cb1, cb2, cb3, cb4;
    private Container d;
    private final String[] drugs = {"Mucolite syrup", "Tusca Syrup", "Adovas syrup", "Antacid", "Paracetamol", "Flexi", "Napa"};
    private final String[] drugs1 = {"Flexi", "Napa"};
    private final String[] drugs2 = {"Mucolite syrup-100g", "Tusca Syrup-100g", "Adovas syrup-80g", "Antacid-4g", "Paracetamol-5g", "Flexi-10g", "Napa-3g", "Mucolite syrup-150g", "Tusca Syrup-150g"};
    private final String[] drugs3 = {"Antacid", "Paracetamol", "Mucolite syrup"};
    private final String[] drugs4 = {"Tusca Syrup", "Adovas syrup"};

    //creating contructor and calling the method for execution
    Frame4() {

        initcomponents();

    }

    public void initcomponents() {
        icon = new ImageIcon(getClass().getResource("Cross2.jpg"));
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(300, 30, 700, 700);
        this.setTitle("Drug panel");
        d = this.getContentPane();
        d.setLayout(null);
        d.setBackground(Color.LIGHT_GRAY);

        label1 = new JLabel("Available drugs: "); //label
        label1.setBounds(50, 40, 100, 50);
        d.add(label1);

        cb = new JComboBox(drugs); //combobox creating
        cb.setBounds(150, 50, 130, 30);
        cb.setEditable(true);
        d.add(cb);

        label2 = new JLabel("Quantities of the drugs: "); //label
        label2.setBounds(300, 40, 200, 50);
        d.add(label2);

        cb1 = new JComboBox(drugs2); //combobox creating
        cb1.setBounds(445, 50, 200, 30);
        cb1.setEditable(true);
        d.add(cb1);

        label3 = new JLabel("Most demanded drugs: "); //label
        label3.setBounds(50, 110, 200, 50);
        d.add(label3);

        cb2 = new JComboBox(drugs3); //combobox creating
        cb2.setBounds(190, 120, 100, 30);
        cb2.setEditable(true);
        d.add(cb2);

        label4 = new JLabel("Most profitable drugs: ");//label
        label4.setBounds(300, 110, 200, 50);
        d.add(label4);

        cb3 = new JComboBox(drugs4);//combobox creating
        cb3.setBounds(445, 120, 200, 30);
        cb3.setEditable(true);
        d.add(cb3);

        label3 = new JLabel("Information of the drugs: ");//label
        label3.setBounds(50, 245, 200, 50);
        d.add(label3);

        label5 = new JLabel("Stock out drugs: ");//label
        label5.setBounds(50, 180, 100, 50);
        d.add(label5);

        cb4 = new JComboBox(drugs1);//combobox creating
        cb4.setBounds(150, 190, 130, 30);
        cb4.setEditable(true);
        d.add(cb4);

        //table
        String data[][] = {{"Mucolite syrup", "100g", "60/-"},
        {"Tusca Syrup", "100g", "100/-"},
        {"Adovas syrup", "80g", "85/-"},
        {"Antacid", "4g", "4/-"},
        {"Paracetamol", "5g", "2/-"},
        {" ", " ", " "},
        {" ", " ", " "}};
        String column[] = {"Drug Name", "Quantity", "Price"};
        table = new JTable(data, column);
        table.setBounds(50, 290, 200, 300);
        table.setSize(300, 120);
        table.setVisible(true);
        d.add(table);

        //importing an image
        i = new ImageIcon(getClass().getResource("PicsArt_06-03-05.09.26(1).png"));
        imgLabel = new JLabel(i);
        imgLabel.setBounds(200, 120, i.getIconWidth(), i.getIconHeight());
        d.add(imgLabel);

        description = new JLabel("Description: "); //label
        description.setBounds(50, 450, 120, 40);
        d.add(description);

        ta = new JTextArea("No work in this week"); // textarea creating
        ta.setBounds(160, 450, 150, 150);
        d.add(ta);

        B1 = new JButton("Previous"); //button
        B1.setBounds(50, 600, 90, 20);
        d.add(B1);
        B1.addActionListener(new ActionListener() { //button acess
            @Override
            public void actionPerformed(ActionEvent ae) {

                dispose();//closing present frame
                Frame frame = new Frame();
                frame.setVisible(true);

            }
        });
    }

    public static void main(String[] args) {
        Frame4 frame = new Frame4();
        frame.setVisible(true);
    }
}
