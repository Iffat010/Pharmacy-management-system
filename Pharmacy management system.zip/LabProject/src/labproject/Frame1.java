package labproject;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Frame1 extends JFrame {

    private final JLabel username;
    private final JLabel password;
    private final JLabel description;
    private JTextField tf;
    private JPasswordField pf;
    private final JButton LoginB, clearB, B1;

    private final Container c;
    private final JTextArea ta;
    private final JScrollPane scroll;
    private final ImageIcon icon;

    Frame1() {
        icon = new ImageIcon(getClass().getResource("Cross2.jpg"));
        this.setIconImage(icon.getImage());        
        this.setBounds(300, 200, 500, 500);
        this.setTitle("Doctor Panel");
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.LIGHT_GRAY);

        username = new JLabel("Username: ");
        username.setBounds(50, 50, 120, 40);

        c.add(username);

        tf = new JTextField();
        tf.setBounds(170, 50, 200, 40);

        c.add(tf);

        password = new JLabel("Password: ");
        password.setBounds(50, 120, 120, 40);

        c.add(password);

        pf = new JPasswordField();
        pf.setBounds(170, 120, 200, 40);

        c.add(pf);

        LoginB = new JButton("Login");
        LoginB.setBounds(150, 190, 90, 40);

        c.add(LoginB);

        clearB = new JButton("Clear");
        clearB.setBounds(280, 190, 90, 40);

        c.add(clearB);

        clearB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                tf.setText("");
                pf.setText("");
            }
        });
        LoginB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String username = tf.getText();
                String password = pf.getText();

                if (username.equals("Priya Sharma") && password.equals("vugichugi")) {
                    JOptionPane.showMessageDialog(null, " Login successful ");
                    dispose();

                } else {
                    JOptionPane.showMessageDialog(null, "    invalid ");
                }
            }
        });

        description = new JLabel("Description: ");
        description.setBounds(50, 270, 120, 40);

        c.add(description);

        ta = new JTextArea("City Pharmacy has a doctor,\nPriya Sharma.\nAge: 40\nHonors and Masters from Dhaka Medical College. \nPhone number: 0168*******");
        scroll = new JScrollPane(ta);
        scroll.setBounds(170, 270, 200, 160);
        c.add(scroll);

        B1 = new JButton("Previous");
        B1.setBounds(30, 420, 90, 20);
        c.add(B1);
        B1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                dispose();//closing present frame
                Frame frame = new Frame();
                frame.setVisible(true);

            }
        });

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public static void main(String[] args) {

        Frame1 frame = new Frame1();
        frame.setVisible(true);
    }

}
