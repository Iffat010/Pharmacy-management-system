package labproject;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Frame extends JFrame {

    private final JButton B1, B2, B3, B4;
    private final Container d;
    private final ImageIcon icon;
//making constructor
    Frame() {
        icon = new ImageIcon(getClass().getResource("Cross2.jpg"));
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(300, 200, 500, 500);
        this.setTitle("Panel");

        d = this.getContentPane();
        d.setLayout(null);
        d.setBackground(Color.LIGHT_GRAY);

        B1 = new JButton("Doctor");// button
        B1.setBounds(190, 60, 110, 50);
        d.add(B1);
        B1.addActionListener(new ActionListener() { //button acess
            @Override
            public void actionPerformed(ActionEvent ae) {

                dispose();
                Frame1 frame = new Frame1();
                frame.setVisible(true);

            }
        });

        B2 = new JButton("Pharmacists");// button
        B2.setBounds(190, 160, 110, 50);
        d.add(B2);
        B2.addActionListener(new ActionListener() { //access button
            @Override
            public void actionPerformed(ActionEvent ae) {

                dispose();
                Frame2 frame = new Frame2();
                frame.setVisible(true);

            }
        });

        B3 = new JButton("Co-worker"); // button
        B3.setBounds(190, 260, 110, 50);
        d.add(B3);
        B3.addActionListener(new ActionListener() { //access button
            @Override
            public void actionPerformed(ActionEvent ae) {

                dispose();
                Frame3 frame = new Frame3();
                frame.setVisible(true);

            }
        });

        B4 = new JButton("Drug");
        B4.setBounds(190, 360, 110, 50);
        d.add(B4);
        B4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                dispose();//closing present frame
                Frame4 frame = new Frame4();
                frame.setVisible(true);

            }
        });

    }

    public static void main(String[] args) {

        Frame frame = new Frame();
        frame.setVisible(true);
    }

}
