package labproject;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LogIn extends JFrame {

    private final JLabel username, password;
    private JTextField tf;
    private JPasswordField pf;
    private final JButton LoginB, clearB;
    private final Container c;
    private final Font f;
    private final ImageIcon icon;
//making constructor
    LogIn() {
        icon = new ImageIcon(getClass().getResource("Cross2.jpg"));
        this.setIconImage(icon.getImage());
        this.setBounds(300, 200, 500, 500);
        this.setTitle("Log in");

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.LIGHT_GRAY);

        f = new Font("Arial", Font.BOLD, 16);

        username = new JLabel("Username: "); //creat label
        username.setBounds(50, 50, 120, 40);
        username.setFont(f);
        c.add(username);

        tf = new JTextField(); // creat field
        tf.setBounds(170, 50, 200, 40);
        tf.setFont(f);
        c.add(tf);

        password = new JLabel("Password: "); //label
        password.setBounds(50, 120, 120, 40);
        password.setFont(f);
        c.add(password);

        pf = new JPasswordField(); //field
        pf.setBounds(170, 120, 200, 40);
        pf.setFont(f);
        c.add(pf);

        LoginB = new JButton("Login"); // button
        LoginB.setBounds(150, 190, 90, 50);
        LoginB.setFont(f);
        c.add(LoginB);

        clearB = new JButton("Clear"); //button
        clearB.setBounds(280, 190, 90, 50);
        clearB.setFont(f);
        c.add(clearB);

        //access button
        clearB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                tf.setText("");
                pf.setText("");
            }
        });
        //access button
        LoginB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String username = tf.getText();
                String password = pf.getText();

                if (username.equals("Pinky") && password.equals("123")) {
                    JOptionPane.showMessageDialog(null, " Login successful ");
                    dispose();//closing present frame
                    Frame frame = new Frame();
                    frame.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "    invalid ");
                }
            }
        });

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
//creat object and make visible
        LogIn frame = new LogIn();
        frame.setVisible(true);
    }
}
